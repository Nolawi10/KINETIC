import { useEffect, useState } from 'react';
import { apiClient, API_URL } from '@/lib/api-client';

export type BackendState = 'checking' | 'online' | 'offline';

export interface BackendStatus {
  /** Reachability of the Flask API (`/api/health`). */
  state: BackendState;
  /** Number of trained models reported by `/api/models` (0 while offline). */
  models: number;
  /** Base URL the client talks to, useful for tooltips/debugging. */
  apiUrl: string;
}

/** Pure label formatter so footer copy is testable without rendering. */
export function formatBackendStatus({ state, models }: Pick<BackendStatus, 'state' | 'models'>): string {
  if (state === 'checking') return 'API: CONNECTING…';
  if (state === 'offline') return 'API: OFFLINE';
  return `API: ONLINE · ${models} MODEL${models === 1 ? '' : 'S'}`;
}

/** Landing-page wording ("STATUS: …"), kept separate from the footer chip. */
export function formatLandingStatus(state: BackendState): string {
  if (state === 'checking') return 'STATUS: CONNECTING…';
  if (state === 'offline') return 'STATUS: API OFFLINE';
  return 'STATUS: API ONLINE';
}

const POLL_INTERVAL_MS = 30_000;

/**
 * Polls the KINETIC Flask backend so the UI can show a real connection state
 * instead of a hard-coded one. Re-checks every 30s while mounted.
 */
export function useBackendStatus(): BackendStatus {
  const [state, setState] = useState<BackendState>('checking');
  const [models, setModels] = useState(0);

  useEffect(() => {
    let active = true;

    const check = async () => {
      try {
        await apiClient.healthCheck();
        const listed = await apiClient.listModels().catch(() => ({ models: [], count: 0 }));
        if (!active) return;
        setModels(listed.count);
        setState('online');
      } catch {
        if (!active) return;
        setModels(0);
        setState('offline');
      }
    };

    void check();
    const id = window.setInterval(check, POLL_INTERVAL_MS);
    return () => {
      active = false;
      window.clearInterval(id);
    };
  }, []);

  return { state, models, apiUrl: API_URL };
}
