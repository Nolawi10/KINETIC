export const API_URL: string = import.meta.env['VITE_API_URL'] || 'http://localhost:5000';

export interface TrainingSession {
  id: string;
  created_at: string;
  discipline: string;
  duration_seconds: number;
  strikes: number;
  max_speed: number;
  simulated: boolean;
  user_id?: string;
}

export interface PredictionRequest {
  model: string;
  features: number[];
}

export interface PredictionResponse {
  prediction: number;
  probability?: number;
  model: string;
}

export interface CoachingPreset {
  id: string;
  title: string;
  tag: string;
  tone: string;
  discipline: string;
  parameters: string[];
}

class ApiClient {
  private baseUrl: string;

  constructor(baseUrl: string = API_URL) {
    this.baseUrl = baseUrl;
  }

  private async request<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<T> {
    const url = `${this.baseUrl}${endpoint}`;
    const response = await fetch(url, {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
      ...options,
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'API request failed');
    }

    return response.json();
  }

  async healthCheck(): Promise<{ status: string; timestamp: string; service: string }> {
    return this.request('/api/health');
  }

  async listModels(): Promise<{ models: string[]; count: number }> {
    return this.request('/api/models');
  }

  async predict(data: PredictionRequest): Promise<PredictionResponse> {
    return this.request('/api/predict', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  async getTrainingSessions(params?: {
    range?: string;
    discipline?: string;
  }): Promise<{ sessions: TrainingSession[]; count: number }> {
    const queryParams = new URLSearchParams();
    if (params?.range) queryParams.append('range', params.range);
    if (params?.discipline) queryParams.append('discipline', params.discipline);

    const endpoint = `/api/training-sessions${queryParams.toString() ? `?${queryParams.toString()}` : ''}`;
    return this.request(endpoint);
  }

  async saveTrainingSession(data: Omit<TrainingSession, 'id' | 'created_at'>): Promise<{
    message: string;
    session: TrainingSession;
  }> {
    return this.request('/api/training-sessions', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  async analyzeSparring(data: {
    video_url?: string;
    frames?: Array<{ time: number; image: string }>;
  }): Promise<any> {
    return this.request('/api/analyze-sparring', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  async receiveTelemetry(data: {
    timestamp: number;
    impact_zone?: string;
    force?: number;
    imu_data?: any;
    pose_data?: any;
  }): Promise<{ status: string; timestamp: string }> {
    return this.request('/api/telemetry', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  async getCoachingPresets(): Promise<{ presets: CoachingPreset[] }> {
    return this.request('/api/coaching-presets');
  }
}

export const apiClient = new ApiClient();
